<?php
session_start();

// Cerramos la variable de usuario y de logueado
unset($_SESSION['usuario']);
unset($_SESSION['logueado']);

// Cerramos la sesión
session_destroy();

//Redirigir a index
header('Location: index.php');
exit;
?>