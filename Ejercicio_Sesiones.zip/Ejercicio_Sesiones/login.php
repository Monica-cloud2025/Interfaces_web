<?php
session_start();

//Valida usuario
$usuario_correcto='admin';
$contrasenia_correcta='1234';
$mensaje_error = '';

//Recoge datos del formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['usuario'] ?? '';
    $contrasenia = $_POST['contrasenia'] ?? '';
    //Comprueba si los datos son correctos
    if ($usuario === $usuario_correcto && $contrasenia === $contrasenia_correcta) {
        $_SESSION['usuario'] = $usuario;
        $_SESSION['logueado'] = true;
        //Redirige al dashboard
        header('Location: dashboard.php');
        exit();
    } else {
        $mensaje_error= "Usuario o contraseña incorrecta. Intente de nuevo<br>";
    }
}       
?>
<!DOCTYPE html>
<html lang="es" dir="ltr">
<head>
    <meta charset="utf-8">
    <tittle>Página de Login</tittle>
</head>
<body>
    <H1>Bienvenido a la página de Inicio de Sesión</H1>
    <?php 
    // Muestra el error
    if (!empty($mensaje_error)) {
        print '<p>' . $mensaje_error . '</p>';
    }
    ?>
        <form action="#" method="POST">
            <label for="usuario">Usuario:</label><br>
            <input type="text" name="usuario" id = "nombre" placeholder = "usuario" requiered><br><br>
            <label for="contrasenia">Contraseña:</label><br>
            <input type="password" id="contrasenia" name="contrasenia" placeholder="Contrasenia"><br><br>

            <input type="submit" value="Registrarse">
        </form>
</body>
</html>