<?php
session_start();
// Verifico si el usuario ha iniciado sesión
$logueado = isset($_SESSION['logueado']) && $_SESSION['logueado'] === true;

?>
<!DOCTYPE html>
<html lang="es" dir="ltr">
<head>
    <meta charset="UTF-8">
    <title>Página Principal</title>
</head>
<body>
    <h1>Página Principal</h1>
    <?php
    if ($logueado): 
        $nombreUsuario = $_SESSION['usuario']; 
    ?>
        <p>¡ Bienvenido <?php print ($nombreUsuario); ?> !</p>
        <p><a href="dashboard.php">Ir al Dashboard</a></p>
        <p><a href="logout.php">Cerrar Sesión</a></p>
    <?php else: ?>
        <p>Aún no has iniciado sesión.</p>
        <p><a href="login.php">Ir a Inicio de Sesión</a></p>
    <?php endif; ?>
</body>
</html>
