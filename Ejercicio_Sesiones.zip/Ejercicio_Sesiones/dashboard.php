<?php
session_start();

// Comprobamos si el usuario está logueado
if (!isset($_SESSION['logueado']) || $_SESSION['logueado'] !== true) {
    // Si no está logueado, redirigimos a login
    header('Location: login.php');
    exit;
}
$usuario = $_SESSION['usuario'];
?>
<!DOCTYPE html>
<html lang="es" dir="ltr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
</head>
<body>
    <h2>Dashboard Área Clientes</h2>
    <p>Bienvenido a tu área privada <?php print ($usuario); ?></p>
    <p>Información para usuarios autenticados.</p>
    <p>Hora de acceso: <?php print date('H:i:s'); ?></p>
    <p><a href="index.php">Volver a la página principal</a></p>
    <p><a href="logout.php">Cerrar Sesión</a></p>
</body>
</html>